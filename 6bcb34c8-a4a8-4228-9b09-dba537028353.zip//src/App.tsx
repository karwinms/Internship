import React from "react";

const Hero = () => {
  return (
    <section className="hero">
      <h1>Welcome to our Ecommerce Store!</h1>
      <p>Explore our collection of products and start shopping today!</p>
      <button>Shop Now</button>
    </section>
  );
};

export default Hero;
